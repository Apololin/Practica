public abstract class Puerta {

    boolean bloqueada = true; //Door state, false if opened true if closed

    public static Puerta bloquear(Puerta puerta) { //it blocks de the door and returns the door blocked
        puerta.bloqueada = true;
        System.out.println("Puerta bloqueada");
        return puerta;
    }
    public static Puerta desbloquear(Puerta puerta) { //it unblocks the door and returns the door unlocked

        puerta.bloqueada = false;
        System.out.println("Puerta desbloqueada");
        return puerta;

    }

}
