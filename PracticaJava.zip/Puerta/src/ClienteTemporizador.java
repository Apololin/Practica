public interface ClienteTemporizador  {

    public static void timeout() {

    }
}
