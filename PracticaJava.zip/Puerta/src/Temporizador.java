import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;


public class Temporizador extends PuertaTemporizada implements ClienteTemporizador{

    public static Puerta registrar(PuertaTemporizada puertaTemp){ // This method collects the users choice for blocking or unblocking the door
        System.out.println("Pulse 1 para abrir la puerta, 2 para bloquearla");
        Scanner reader = new Scanner(System.in);
        int opcion = reader.nextInt();
        if (opcion == 1){
           return desbloquear(puertaTemp);
        }else if (opcion == 2){
           return bloquear(puertaTemp);
        }else{
            System.out.println("OPCION NO RECONOCIDA");
            return puertaTemp;
        }
    }

    public void timer(PuertaTemporizada puertaTemp){ //Timer that runs when the door is unlocked, once it finishes we call timeout()
        TimerTask timerTask = new TimerTask() {
            @Override
            public void run() {
                if(puertaTemp.bloqueada == false){
                     timeout(puertaTemp);
                }
            }
        };
        Timer timer= new Timer();
        timer.schedule(timerTask,5000,10000); //Timers setup
    }

}
