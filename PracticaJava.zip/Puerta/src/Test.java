
public class Test {

    private static Temporizador temp= new Temporizador();
    private static boolean cont = true;


    public static void main(String[] args) {

       Temporizador temp = new Temporizador(); //We create an instance of a timer and an instance of a door
       PuertaTemporizada puertaTemporizada = new PuertaTemporizada();

       System.out.println("True: bloqueada");
        System.out.println("False: desbloqueada");
        System.out.println("Estado actual: "+ puertaTemporizada.bloqueada);// the doors initial state its blocked

       while (cont){ //Loop for the program to keep on

          puertaTemporizada = (PuertaTemporizada) temp.registrar(puertaTemporizada); //Call the election method
          temp.timer(puertaTemporizada); //Call for the Timer

       }

    }

}
