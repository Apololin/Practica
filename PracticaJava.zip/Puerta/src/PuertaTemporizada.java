
public class PuertaTemporizada extends Puerta implements ClienteTemporizador {

    public static Puerta puerta;

    public static Puerta timeout(Puerta puerta){ // Here we receive the timers signal when it has finished, we block it if it is unblocked

        if (puerta.bloqueada){ // If the door is blocked do nothing
            return puerta;
        }else{
             // if the door is unblocked, we block it
            return bloquear(puerta);
        }

    }
}
