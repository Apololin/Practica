import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

public class PracticaSelenium {

    static WebDriver driver;

    @Test( priority = 0) // We set the priority for the Test, its done as a single test, in this case priority is careless

    public void PracticaSelenium() throws InterruptedException{

        System.setProperty("webdriver.chrome.driver","C:\\Intellij\\chromedriver.exe"); //Properties for the chrome controller adding implicit wait, the path of the driver depends on the terminal we are executing the program
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

        driver.get("https://www.edureka.co/"); //We load the initial website in the chrome browser
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        driver.findElement(By.cssSelector(".login_click.login-vd.giTrackElementHeader")).click(); //click first element

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        Actions actions = new Actions(driver); //An action its set for placing the email account into the corresponding box
        actions.moveToElement(driver.findElement(By.id("si_popup_email")));
        Thread.sleep(2000);
        actions.click();
        actions.sendKeys("alberto.polo-linares@capgemini.com"); //Here goes the users email

        Thread.sleep(2000); //Repeat for the password what its done with the email
        actions.build().perform();
        actions.moveToElement(driver.findElement(By.id("si_popup_passwd")));
        Thread.sleep(2000);
        actions.click();
        actions.sendKeys("Atleti!1705");
        Thread.sleep(2000);
        actions.build().perform();

        actions.moveToElement(driver.findElement(By.xpath("//button[@class='clik_btn_log btn-block']")));//Looking for and preparing an action to click the login button
        Thread.sleep(3000);
        actions.click();//click

        actions.build().perform(); //Execute actions


        //Going to my profile section

        driver.findElement(By.xpath("//a[@class='dropdown-toggle trackButton']//img[@class='img30']")).click();// expand the user options list
        Thread.sleep(1000);
        driver.findElement(By.xpath("//a[normalize-space()='My Profile']")).click();//going to My profile option
        Thread.sleep(2000);
        WebDriverWait waitElement = new WebDriverWait(driver,20); //Wait element in case the website takes some time to load
        waitElement.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//li[@class='active']//a[@data-toggle='tab'][contains(text(),'My Profile')]")));


        driver.findElement(By.xpath("//li[@class='active']//a[@data-toggle='tab'][contains(text(),'My Profile')]")).click();
        String Pagetitle = driver.getTitle();
        driver.findElement(By.xpath("//div[@class='personal-details']//i[@class='icon-pr-edit']")).click();
        driver.findElement(By.xpath("//input[@id='fullName']")).clear(); //Clearing the textbox in case there was anything saved
        driver.findElement(By.xpath("//input[@id='fullName']")).sendKeys("Alberto"); //Adding the users name
        Thread.sleep(3000);
        driver.navigate().to("https://learning.edureka.co/my-profile");
        Thread.sleep(3000);

        //Updating personal information

        driver.navigate().to("https://learning.edureka.co/onboarding/careerinterests");
        Thread.sleep(3000);
        Select dropdownCurrentJob = new Select(driver.findElement(By.xpath("//select[@name='interestedJob']")));
        Thread.sleep(3000);
        dropdownCurrentJob.selectByVisibleText("Software Testing");
        Thread.sleep(3000);
        Select dropdownEmployementType = new Select(driver.findElement(By.xpath("//select[@name='elementType']")));
        Thread.sleep(3000);dropdownEmployementType.selectByVisibleText("Both");


        driver.findElement(By.xpath("//input[@placeholder='Enter your city']")).clear(); //clearing textbox in case there was anything saved
        driver.findElement(By.xpath("//input[@placeholder='Enter your city']")).sendKeys("Madrid");


        Select dropdownCTC = new Select(driver.findElement(By.xpath("//select[@name='lastDrawnSalaryUS']"))); //expanding salaries list
        Thread.sleep(3000);dropdownCTC.selectByVisibleText("$50K-$75K");

        //Clicking and sending the options of the form

        driver.findElement(By.xpath("//label[contains(text(),'Yes')]")).click();
        driver.findElement(By.xpath("//input[@name='preferredCity']")).clear();
        driver.findElement(By.xpath("//input[@name='preferredCity']")).sendKeys("Albacete");
        driver.findElement(By.xpath("//button[normalize-space()='Next']")).click();
        Thread.sleep(3000);

        //Exploring the blogs and going back to the main website

        driver.findElement(By.xpath("//button[@class='btn pull-right onboarding-primary-button']")).click();
        Thread.sleep(3000);
        driver.navigate().to("https://learning.edureka.co/");
        Thread.sleep(3000);
        driver.findElement(By.xpath("//span[@class='user_name']")).click();
        Thread.sleep(3000);

        //Doing the logout and checking any exception
        driver.findElement(By.xpath("//a[contains(text(),'Log Out')]")).click();
        Thread.sleep(3000);

        try {Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
